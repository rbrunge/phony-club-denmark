﻿define("epi-cms/component/Versions", [
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/connect",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/on",
    "dojo/string",
    "dojo/topic",
    "dojo/when",
    "dojox/html/entities",

// DGrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",

// EPi Framework
    "epi",
    "epi/dependency",
    "epi/username",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/command/_WidgetCommandProviderMixin",
    "epi/shell/command/withConfirmation",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/Tooltip",
    "epi/shell/widget/dialog/Alert",
    "epi/shell/widget/dialog/Confirmation",

// EPi CMS
    "epi-cms/_MultilingualMixin",
    "epi-cms/ApplicationSettings",
    "epi-cms/core/ContentReference",
    "epi-cms/component/command/DeleteVersion",
    "epi-cms/component/command/DeleteLanguageBranch",
    "epi-cms/component/command/SetCommonDraft",
    "epi-cms/command/ShowAllLanguages",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/widget/_GridWidgetBase",

// Resources
    "epi/i18n!epi/cms/nls/episerver.cms.components.versions"

], function (
// Dojo
    array,
    declare,
    lang,
    connect,
    aspect,
    domClass,
    on,
    string,
    topic,
    when,
    entities,

// DGrid
    OnDemandGrid,
    Selection,

// EPi Framework
    epi,
    dependency,
    username,
    TypeDescriptorManager,
    _WidgetCommandProviderMixin,
    withConfirmation,
    _FocusableMixin,
    Tooltip,
    Alert,
    Confirmation,

// EPi CMS
    _MultilingualMixin,
    ApplicationSettings,
    ContentReference,
    DeleteVersion,
    DeleteLanguageBranch,
    SetCommonDraft,
    ShowAllLanguagesCommand,
    ContentActionSupport,
    _GridWidgetBase,

// Resources
    resources
) {

    // module:
    //		epi-cms/component/Versions
    // summary:
    //		This component will list all versions of a content item.
    return declare([_GridWidgetBase, _WidgetCommandProviderMixin, _FocusableMixin, _MultilingualMixin], {

        // showAllLanguages: [readonly] Boolean
        //		Flag which indicates whether to show all languages. Value is true if all languages should be shown; otherwise false.
        showAllLanguages: true,

        // isMultilingual:  Boolean
        //		Flag which indicates whether the Show All Languages command should be enabled or disabled, based on Read access right and the number of available languages.
        isMultilingual: false,

        _tooltips: [],
        postMixInProperties: function () {
            // summary:
            //		Called after constructor parameters have been mixed-in; sets default values for parameters that have not been initialized.
            // tags:
            //		protected

            this._commonDrafts = {};

            this.storeKeyName = "epi.cms.contentversion";
            this.ignoreVersionWhenComparingLinks = false;

            this.inherited(arguments);

            this._currentContentLanguage = ApplicationSettings.currentContentLanguage;
            this.connect(this.store, "onItemChanged", "_onItemChanged");

            var registry = dependency.resolve("epi.storeregistry");
            this._contentStore = registry.get("epi.cms.contentdata");
        },

        buildRendering: function () {
            // summary:
            //		Construct the UI for this widget with this.domNode initialized as a dgrid.
            // tags:
            //		protected

            this.inherited(arguments);

            var customGridClass = declare([OnDemandGrid, Selection]);
            this.grid = new customGridClass({
                columns: {
                    language: { label: epi.resources.header.language },
                    statusName: {
                        label: epi.resources.header.status,
                        renderCell: function (item, value, node, options) {
                            var html = item.statusName;
                            if (item.isCommonDraft) {
                                html = '<span class="dijitReset dijitInline dijitIcon epi-iconPrimary epi-floatRight"></span>' + item.statusName;
                            }
                            node.innerHTML = html;
                        }
                    },
                    savedDate: {
                        label: epi.resources.header.saved,
                        formatter: this._localizeDate
                    },
                    savedBy: {
                        label: epi.resources.header.by,
                        formatter: this._createUserFriendlyUsername
                    }
                },
                store: this.store,
                selectionMode: "single",
                selectionEvents: "click,dgrid-cellfocusin",
                sort: [{ attribute: "savedDate", descending: true }]
            }, this.domNode);
        },

        postCreate: function () {
            this.add("commands", new ShowAllLanguagesCommand({ model: this }));

            this._commonDraftCommand = new SetCommonDraft();
            this._deleteVersionCommand = new DeleteVersion();
            this._deleteLanguageBranchCommand = new DeleteLanguageBranch();

            this.own(aspect.after(this._commonDraftCommand, "execute", lang.hitch(this, function (deferred) {
                    deferred.then(null, lang.hitch(this, this._onSetCommonDraftFailure));
                })),
                // Refresh after delete successfully
                aspect.after(this._deleteVersionCommand, "execute", lang.hitch(this, function (deferred) {
                    deferred.then(lang.hitch(this, this._onDeleteVersionSuccess), lang.hitch(this, this._onDeleteVersionFailure));
                })),
                aspect.after(this._deleteLanguageBranchCommand, "execute", lang.hitch(this, function (deferred) {
                    deferred.then(lang.hitch(this, this._onDeleteVersionSuccess), lang.hitch(this, this._onDeleteVersionFailure));
            })));

            this.add("commands", this._commonDraftCommand);
            this.add("commands", withConfirmation(this._deleteVersionCommand, null, {
                title: resources.deletemenuitemtitle,
                heading: resources.deleteversion.note,
                description: resources.deleteversion.confirmquestion
            }));

            this._deleteLanguageBranchSettings = {
                cancelActionText: epi.resources.action.cancel,
                setFocusOnConfirmButton: false
            };
            this.add("commands", withConfirmation(this._deleteLanguageBranchCommand, null, this._deleteLanguageBranchSettings));
        },

        startup: function () {
            // summary: Overridden to connect a store to a DataGrid.

            if (this._started) {
                return;
            }

            this.inherited(arguments);

            this.own(aspect.around(this.grid, "renderRow", lang.hitch(this, this._aroundRenderRow)));

            this._toggleLanguage(this.showAllLanguages);
            this.fetchData();
        },

        _setShowAllLanguagesAttr: function (value) {
            this._set("showAllLanguages", value);
            this._toggleFilterByLanguage(value);
        },

        destroy: function () {
            this.inherited(arguments);
            this._destroyTooltips();
        },

        _onItemChanged: function () {
            // summary:
            //      Fetches new data when an item is changed in the store.
            // tags:
            //      private

            //We force a new get when a value has changed in the store, otherwise we might have several commondrafts
            this.fetchData();
        },

        fetchData: function () {
            // summary:
            //		Updates the grid with the new data.
            // tags:
            //		private

            when(this.getCurrentContent(), lang.hitch(this, function (item) {
                if (!item) {
                    return;
                }
                this._destroyTooltips();

                if (item.accessMask && !ContentActionSupport.hasAccess(item.accessMask, ContentActionSupport.accessLevel.Edit) ||
                    item.providerCapabilityMask && !ContentActionSupport.hasProviderCapability(item.providerCapabilityMask, ContentActionSupport.providerCapabilities.Edit)) {
                    this._showErrorMessage(epi.resources.messages.nopermissiontoviewdata);
                    this.set("isMultilingual", false); // disable Show All Language command since user does not have access right to view data
                    this._updateMenu(item);
                    return;
                }
                var query = { contentLink: item.contentLink };
                if (!this._allLanguages) {
                    query.language = this._currentContentLanguage;
                }
                this.grid.set("query", query);

                // enable Show All Language command
                this.set("isMultilingual", true);
            }));
        },

        _destroyTooltips: function () {
            // summary:
            //  destroy all tooltips
            array.forEach(this._tooltips, function (tooltip) {
                tooltip.destroyRecursive();
            });
            this._tooltips = [];
        },

        _aroundRenderRow: function (original) {
            // summary:
            //		Called 'around' the renderRow method in order to add a class which indicates published state.
            // tags:
            //		private

            return lang.hitch(this, function (item) {
                // If item is a common draft add it to the hash map.
                if (item.isCommonDraft) {
                    var common = this._commonDrafts[item.language];
                    if (common && common != item.contentLink) {
                        this._removeCommonDraft(common);
                    }
                    this._commonDrafts[item.language] = item.contentLink;
                }

                // Call original method
                var row = original.apply(this.grid, arguments);

                // Add state specific classes
                domClass.toggle(row, "dgrid-row-published", item.status === ContentActionSupport.versionStatus.Published);

                // Create the tooltip for this item row.
                this._createTooltip(item, row);

                return row;
            });
        },

        _onSelect: function (e) {
            var item = e.rows[0].data;

            this._updateMenu(item);

            this.inherited(arguments);
        },

        _updateMenu: function (item) {
            this._commonDraftCommand.set("model", item);
            this._deleteVersionCommand.set("model", item);

            when(this._contentStore.get(item.contentLink), lang.hitch(this, function (content) {
                if (content && content.currentLanguageBranch) {
                    var heading = lang.replace(resources.deletelanguagebranch.label, [content.currentLanguageBranch.name]),
                        description = TypeDescriptorManager.getResourceValue(content.typeIdentifier, "deletelanguagebranchdescription");

                    lang.mixin(this._deleteLanguageBranchSettings, {
                        confirmActionText: heading,
                        description: lang.replace(description, [entities.encode(content.name), content.currentLanguageBranch.name]),
                        title: heading
                    });
                    this._deleteLanguageBranchCommand.set("label", heading);
                }

                this._deleteLanguageBranchCommand.set("model", content);
            }));
        },

        _showNotificationMessage: function (notification) {
            // summary:
            //     Show a notification message
            // notification:
            //     The notification message
            var dialog = new Alert({
                title: resources.notificationtitle,
                description: notification
            });
            dialog.show();
        },

        _selectCommonDraftVersion: function (uri) {
            // summary:
            //      Selects the published page version ins the list.
            // tags:
            //      private

            var contextParameters = { uri: uri };
            topic.publish("/epi/shell/context/request", contextParameters, { sender: this });
        },

        _onDeleteVersionSuccess: function () {
            // summary:
            //      Update the current context and display notification.
            // tags:
            //      private

            var contentLink = new ContentReference(this.grid.get("query").contentLink);

            this._selectCommonDraftVersion("epi.cms.contentdata:///" + contentLink.createVersionUnspecificReference().toString());
        },

        _onDeleteVersionFailure: function (response) {
            // summary:
            //      Display alert with the delete failure message.
            // tags:
            //      private

            //If the user clicks cancel in the confirmation dialog we will end up here
            if (!response || !response.status) {
                return;
            }
            else if (response.status === 403) {
                this._showNotificationMessage(resources.deleteversion.cannotdeletepublished);
            } else {
                this._showNotificationMessage(resources.deleteversion.cannotdelete);
            }
        },

        _onSetCommonDraftFailure: function () {
            // summary:
            //      Display notification in the UI of failure.
            // tags:
            //      private

            this._showNotificationMessage(resources.setcommondraft.failuremessage);
        },

        _removeCommonDraft: function (reference) {
            // Refresh the previous common draft item, as it might be changed on the server side.
            if (reference) {
                var item = this.grid.row(reference).data;
                if (item) {
                    item.isCommonDraft = false;
                }
            }
        },

        _toggleFilterByLanguage: function (showAll) {
            // summary:
            //      handles filterByLanguage event.
            // tags:
            //      private
            // sender:
            //      the page version widget that triggers the filterByLanguage event

            when(this.getCurrentContext(), lang.hitch(this, function (currentContext) {
                var query = { contentLink: currentContext.id };

                if (!showAll) {
                    query.language = this._currentContentLanguage;
                }

                this._toggleLanguage(showAll);
                this.grid.set("query", query);

                this._allLanguages = showAll;
            }));
        },

        _toggleLanguage: function (visible) {
            // summary:
            //		Toggles the visibility of the language column.
            // tags:
            //		private

            var value = visible ? "table-cell" : "none";

            this.grid.styleColumn("language", string.substitute("display:${0};", [value]));
        },

        _createTooltip: function (item, row) {
            // summary:
            //    Binds the mouseover and mouseout events to show and hide a tooltip for the row item.
            // tags:
            //    private

            var tooltipRows = [
                {
                    label: epi.resources.header.language,
                    text: epi.resources.language[item.language]
                },
                {
                    label: epi.resources.header.name,
                    text: item.name
                },
                {
                    label: epi.resources.header.status,
                    text: ContentActionSupport.getVersionStatus(item.status)
                },
                {
                    label: resources.saved,
                    text: this._localizeDate(item.savedDate),
                    htmlEncode: false
                },
                {
                    label: resources.by,
                    text: username.toUserFriendlyString(item.savedBy, null, true)
                }
            ];

            var tooltip = new Tooltip({
                connectId: row,
                tooltipRows: tooltipRows
            });
            this._tooltips.push(tooltip);
        }
    });
});
