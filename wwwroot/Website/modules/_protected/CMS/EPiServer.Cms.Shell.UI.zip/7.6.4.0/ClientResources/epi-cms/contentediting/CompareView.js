//>>built
define("epi-cms/contentediting/CompareView",["dojo/_base/declare","epi-cms/contentediting/_View"],function(_1,_2){return _1([_2],{updateView:function(){}});});