define("epi-cms/contentediting/CompareView", [
    "dojo/_base/declare",
    "epi-cms/contentediting/_View"
], function(
    declare,
    _View
) {

    return declare([_View], {

        updateView: function() {
            console.log("Switch to compare mode");
        }
    });
});