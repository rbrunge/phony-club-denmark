﻿define("epi-cms/contentediting/ScheduledPublishSelectorViewModel", [
// Dojo
    "dojo/_base/declare",
    "dojo/Stateful",

//EPi
    "epi/shell/_StatefulGetterSetterMixin",

// Resources
    "epi/i18n!epi/cms/nls/episerver.cms.widget.scheduledpublishselector"
],

function (
// Dojo
    declare,
    Stateful,

// EPi
    _StatefulGetterSetterMixin,

// Resources
    resources
    ) {

    return declare([Stateful, _StatefulGetterSetterMixin], {

        breadcrumbModel: null,

        title: "",

        dateLabel: "",

        dateValue: null,

        scheduleButtonEnabled: false,

        constructor: function () {
            // Create a default date. Set it to noon tomorrow.
            var noonTomorrow = new Date();
            noonTomorrow.setDate(noonTomorrow.getDate() + 1);
            noonTomorrow.setHours(12, 0, 0, 0);

            this.set("dateValue", noonTomorrow);
        },

        _setIsPublishedAttr: function (isPublished) {
            this.set("dateLabel", isPublished ? resources.publishchangeson : resources.publishon);
        },

        _setContentDataAttr: function (contentData) {
            this.set("title", contentData.name);
            this.set("isPublished", !contentData.isPendingPublish);
            this.set("breadcrumbModel", contentData.contentLink);
        },

        _setDateValueAttr: function (value) {
            this._set("dateValue", value);

            this.set("scheduleButtonEnabled", !!value);
        }
    });
});